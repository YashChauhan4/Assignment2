import cv2
import os
# 1) Read image
image = cv2.imread('C:\\Users\\abc\\Desktop\\Group.jpeg.jpg')

# 2) Show image
cv2.imshow('Group.jpeg.jpg', image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 3) Convert image into Gray, Blur, Canny, Dilation & Eroded image
import cv2

# Read the image
image = cv2.imread('C:\\Users\\abc\\Desktop\\tree.png')

# Convert image to gray
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Apply blur
blur_image = cv2.GaussianBlur(gray_image, (7, 7), 0)

# Apply Canny edge detection
canny_image = cv2.Canny(blur_image, 100, 150)

# Apply dilation
dilated_image = cv2.dilate(canny_image, None, iterations=2)

# Apply erosion
eroded_image = cv2.erode(dilated_image, None, iterations=1)

# Display the images
cv2.imshow('Original Image', image)
cv2.imshow('Gray Image', gray_image)
cv2.imshow('Blur Image', blur_image)
cv2.imshow('Canny Image', canny_image)
cv2.imshow('Dilated Image', dilated_image)
cv2.imshow('Eroded Image', eroded_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 4) Resize image into: (i) Smaller than original & (ii) Up to screen size
import cv2

# Read the image
image = cv2.imread('C:\\Users\\abc\\Desktop\\lambo.png')

# Calculate the desired sizes
smaller_size = (int(image.shape[1] / 2), int(image.shape[0] / 2))  # Half the size of the original image
screen_size = (1920, 1080)  # Example screen size

# Resize the image to be smaller than the original
smaller_image = cv2.resize(image, smaller_size)

# Resize the image to fit within the screen size while preserving the aspect ratio
resized_image = cv2.resize(image, screen_size, interpolation=cv2.INTER_AREA)

# Display the images
cv2.imshow('Original Image', image)
cv2.imshow('Smaller Image', smaller_image)
cv2.imshow('Resized Image', resized_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 5) Cropping of image
import cv2

# Read the image
image = cv2.imread('C:\\Users\\abc\\Desktop\\Group.jpeg.jpg')

# Define the coordinates for the region of interest (ROI)
x, y, width, height = 80, 100, 200, 300

# Crop the image using the ROI coordinates
cropped_image = image[y:y+height, x:x+width]

# Display the original image and the cropped image
cv2.imshow('Original Image', image)
cv2.imshow('Cropped Image', cropped_image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 6) Insertion of shapes (rectangle & circle) in the given image
import cv2

# Read the image
image = cv2.imread('C:\\Users\\abc\\Desktop\\lambo.png')

# Insert a rectangle shape
cv2.rectangle(image, (80, 80), (100, 100), (0, 300, 0), 0)  # (100, 100) - top-left corner, (300, 300) - bottom-right corner

# Insert a circle shape
cv2.circle(image, (100, 100), 50, (0, 0, 200), 1)  # (200, 200) - center, 100 - radius

# Display the image with shapes
cv2.imshow('Image with Shapes', image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 7) Join two & three different images
import cv2

# Read the images
image1 = cv2.imread('C:\\Users\\abc\\Desktop\\Group.jpeg.jpg')
image2 = cv2.imread('C:\\Users\\abc\\Desktop\\dog.png')
image3 = cv2.imread('C:\\Users\\abc\\Desktop\\tree.png')

# Join two images horizontally
horizontal_concat = cv2.hconcat([image1, image2])

# Join three images horizontally
horizontal_concat_3 = cv2.hconcat([image1, image2, image3])

# Join two images vertically
vertical_concat = cv2.vconcat([image1, image2])

# Join three images vertically
vertical_concat_3 = cv2.vconcat([image1, image2, image3])

# Display the concatenated images
cv2.imshow('Horizontal Concatenation (2 Images)', horizontal_concat)
cv2.imshow('Horizontal Concatenation (3 Images)', horizontal_concat_3)
cv2.imshow('Vertical Concatenation (2 Images)', vertical_concat)
cv2.imshow('Vertical Concatenation (3 Images)', vertical_concat_3)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 8) Face detection on the given image of a group
import cv2

# Read the image
image = cv2.imread('C:\\Users\\abc\\Desktop\\Group.jpeg.jpg')

# Load the pre-trained face cascade classifier
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')

# Convert the image to grayscale
gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

# Perform face detection
faces = face_cascade.detectMultiScale(gray_image, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

# Draw rectangles around the detected faces
for (x, y, w, h) in faces:
    cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)

# Display the image with face detections
cv2.imshow('Image with Face Detections', image)
cv2.waitKey(0)
cv2.destroyAllWindows()

# 9) Read & Save the video given
import cv2

# Read the input video
video_capture = cv2.VideoCapture('C:\\Users\\abc\\Desktop\\sample-1.mp4')

# Get video properties
fps = video_capture.get(cv2.CAP_PROP_FPS)
width = int(video_capture.get(cv2.CAP_PROP_FRAME_WIDTH))
height = int(video_capture.get(cv2.CAP_PROP_FRAME_HEIGHT))

# Create a VideoWriter object to save the output video
fourcc = cv2.VideoWriter_fourcc(*'mp4v')  # Specify the video codec
output_video = cv2.VideoWriter('C:\\Users\\abc\\Desktop\\sample-1.mp4', fourcc, fps, (width, height))

# Read and process each frame of the video
while video_capture.isOpened():
    ret, frame = video_capture.read()
    if not ret:
        break

    # Display the frame
    cv2.imshow('Video', frame)

    # Write the frame to the output video
    output_video.write(frame)

    if cv2.waitKey(1) == ord('q'):
        break

# Release the video capture and writer objects
video_capture.release()
output_video.release()

# Close all windows
cv2.destroyAllWindows()



